package com.trav.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.trav.qa.base.TestBase;

public class SignUpPage extends TestBase{
	


}
 