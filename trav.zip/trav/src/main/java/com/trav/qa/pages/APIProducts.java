package com.trav.qa.pages;

import com.trav.qa.base.TestBase;

public class APIProducts extends TestBase {

}
