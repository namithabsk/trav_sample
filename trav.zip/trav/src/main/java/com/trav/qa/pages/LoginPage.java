package com.trav.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.trav.qa.base.TestBase;

public class LoginPage extends TestBase {

	
//	page factory or object repo
	@FindBy(id="work_email-2")
	@CacheLookup
	//store element in cache memory and it will increase the speed of framework
	WebElement workEmail;
	
	@FindBy(id="password-2")
	WebElement password;
	
	@FindBy(xpath = "//input[text='Reset Password']")
	WebElement resetPassword;
	
	@FindBy(className = "tds-button--primary login-button")
	WebElement login;
	

	
	
//	Initializing the page objects
	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public static String validateLoginPageTitle() {
		return driver.getTitle();
		}

//	public void verifyLoginPage() {
//		// TODO Auto-generated method stub
//		
//	}
//	
//	public void verifyLoginPage() {
//		workEmail.isDisplayed();
//		password.isDisplayed();
//		resetPassword.isDisplayed();
//	}
//	
//	public HomePage enterValuesForLogin(String un, String pw) {
//		workEmail.sendKeys(un);
//		password.sendKeys(pw);
//		login.click();
//		return new HomePage();
//
//	}
	
	
	
}
