package com.trav.qa.pages;

import org.openqa.selenium.By;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.trav.qa.base.TestBase;

import io.qameta.allure.Step;

public class HomePage extends TestBase{

//	page factory or object repo
	@FindBy(xpath="button[class='tds-button--secondary tds-button--small']")
	WebElement login;
	
	@FindBy(xpath="//input[@id='acm-search']")
	WebElement searchBox;
	
	@FindBy(xpath="//span[normalize-space()='Home']")
	WebElement home;
	
	
	@FindBy(xpath = "//input[text='Explore API Products']")
	WebElement exploreAPIProducts;
	
	@FindBy(xpath= "//button[@title='Search']//*[name()='svg']")
	WebElement search;
	
//	Initializing the page objects
	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	//Actions:
	@Step("Verifing title")
	public String validateHomePageTitle() {
		log.info("Verifing the home page title...");
		
	return driver.getTitle();
	}
	
	public void verifyHomePageComponents() {
		home.isDisplayed();
		}
	
	public LoginPage clickonLogin() {
		login.click();
		return new LoginPage();
		
	}
	
	public void clickOnSearch()
	{
		search.click();
	}
	
//	@Step("Passing different value, we can do it in Allure report using {APIIS}")
	public void verifySearchBox(String searchValue) {
		searchBox.isDisplayed();
		searchBox.sendKeys(searchValue);
		searchBox.sendKeys(Keys.ENTER);
//		mousehover
//		Actions action = new Actions(driver);
//		action.moveToElement(exploreAPIProducts);
		
	}
	
/* select value from drop down
 
public void createsameplemethodtoselectvaluefromdropdown(String title) {
	Select select = new Select(driver.findElement(By.name("title")));
	select.selectByVisibleText(title);
}
*/
	
//	public APIProduct clickonAPIProduct() {
//		exploreAPIProducts.click();
//		return new exploreAPIProducts();
//		
//	}
	
	
	
	
}
