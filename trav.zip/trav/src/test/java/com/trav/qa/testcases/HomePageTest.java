package com.trav.qa.testcases;


import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.trav.qa.pages.HomePage;
import com.trav.qa.util.TestUtil;

import io.qameta.allure.Description;
import io.qameta.allure.Severity;
import io.qameta.allure.SeverityLevel;
import io.qameta.allure.Story;

import com.trav.qa.base.TestBase;

public class HomePageTest extends TestBase {
	HomePage HomePage;
	TestUtil testUtil;
	String sheetName = "search";
	
	public HomePageTest() {
		super();
	}
	
	
	@BeforeMethod
	
	public void setUp() {
		log.info("****************************   Starting test exectution    ***************************");
		intialization();
		HomePage = new HomePage();
	}
	
	@DataProvider
	public Object[][] getSearchTestData()
	{
		Object data[][]= TestUtil.getTestData(sheetName);
		return data;
		
	}
	
	@Test(dataProvider = "getSearchTestData", description ="Verify the home page title")
	@Severity(SeverityLevel.NORMAL)
	@Description("Test case to verify Home Page")
	@Story("US2en")
	public void homePageVerification(String SearchValue) {
		String title= HomePage.validateHomePageTitle();
		Assert.assertEquals(title,"Home | Travelers API Portal","User is not landed on Home Page");
//		HomePage.verifyHomePageComponents();
//		HomePage.clickonLogin();
		HomePage.clickOnSearch();
		HomePage.verifySearchBox(SearchValue);
		System.out.print(SearchValue);
		
//		HomePage.clickonLogin();
	}
	
	@AfterMethod
	public void tearDown() {
		log.info("****************************   Ending test exectution    ***************************");

		driver.quit();
	}
	

}
